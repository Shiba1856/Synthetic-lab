# AD Attack Simulation — Simulation Edition

A local, low-resource educational demo of Active Directory-style directory analysis. It runs without Windows Server, a domain controller, Docker, or LDAP.

**Important:** All directory records and findings in this edition are synthetic. The application does not connect to or attack a real Active Directory environment. Attack paths are potential paths inferred from the synthetic graph, not proof of exploitability.

## Stack
- Frontend: React + Vite
- Backend: FastAPI
- Analysis: Pandas + NetworkX
- Data: JSON files under `backend/data/`

## Requirements
- Python 3.10+
- Node.js 18+ and npm

## Start on Windows

### 1. Backend
Open PowerShell in this folder:

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

If PowerShell blocks activation, use:
```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

API docs: http://127.0.0.1:8000/docs

### 2. Frontend
Open a second PowerShell window:

```powershell
cd frontend
npm install
npm run dev
```

Open the local URL printed by Vite, usually http://localhost:5173.

## Features
- Summary metrics for synthetic users, groups, computers and relationships
- Findings list with severity and explanation
- Relationship graph (simple SVG renderer)
- Potential attack-path list
- Scenario toggles to demonstrate how directory relationships affect findings
- API health and data provenance indicator
- Reset to baseline sample data

## API endpoints
- `GET /api/health`
- `GET /api/summary`
- `GET /api/findings`
- `GET /api/graph`
- `GET /api/attack-paths`
- `GET /api/options`
- `GET /api/evaluation`
- `GET /api/scenarios`
- `POST /api/scenarios/{scenario_id}/toggle`
- `POST /api/reset`

## Data model
- `users.json`: synthetic users
- `groups.json`: synthetic groups
- `computers.json`: synthetic computer accounts
- `memberships.json`: group membership edges
- `permissions.json`: synthetic permission relationships used by the teaching rules

## Limitations
This is a simulated analysis project. It does not collect telemetry, validate credentials, exploit systems, or establish that a path is exploitable. The risk rules are deliberately simple and explainable for a mini project.

## Enhanced edition features
- Deterministic, expanded synthetic directory inventory (500 standard users, 25 privileged identities, 40 service identities, 100 groups, 150 computers, 20 OUs, and hundreds of synthetic relationship records).
- Searchable Directory Inventory page with filters by name, username, department, and ID.
- Ranked, bounded candidate-path analysis with relationship evidence and validation checklist.
- Path details endpoint: `GET /api/attack-paths/{path_id}`.
- Simulated relationship-removal workflow: `POST /api/remediation/simulate` (changes only in-memory synthetic data; Reset baseline restores it).
- Inventory endpoint: `GET /api/inventory`.
- Three scenarios for demonstrating nested privilege, service access, and offboarding hygiene.

### macOS quick start
Backend terminal:
```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```
Second terminal:
```bash
cd frontend
npm install
npm run dev
```
Open the URL Vite prints (usually http://127.0.0.1:5173).

All added data is synthetic and uses no real credentials or live domain. Path results are candidate relationships, not verified exploitability. The remediation action is a local simulation only.

## Relationship graph controls (enhanced)

The Relationship Graph now uses type-separated columns for users, groups, and computers, with visible directional relationship lines. Use the search box to find an object, then click a result or a node to focus the graph on that object and its directly connected neighbors. Use the object-type filter to narrow the view, **Reset view** to return to the overview, and **Show all matches** when you explicitly want the full filtered result set (large result sets may require scrolling). This remains a synthetic visualization, not proof that a real path is exploitable.


## UI improvements in this build

- The relationship graph uses a balanced object-type overview (users, groups, computers) and lets you search, filter, and focus on connected objects. Use **Show all matches** when you want to inspect the larger graph; the canvas scrolls to keep dense graphs usable.
- Risk overview includes a severity donut chart and a count/percentage legend for Critical, High, Medium, Low, and Info findings.
- Potential path **View details** opens an investigation panel immediately, with a local fallback if the optional detail API request fails. Where available, the API enriches each relationship with its synthetic evidence record.
- Finding severity is intentionally mixed by explicit simulation rules: direct membership in named top-tier groups can be Critical; other high-privilege memberships and risky permission edges can be High; service-account review items are Medium; prolonged inactivity can be Low. These are educational heuristics and not a real security verdict.

The dataset is deliberately AD-like but entirely synthetic. Do not present it as exported from a real Active Directory domain.
