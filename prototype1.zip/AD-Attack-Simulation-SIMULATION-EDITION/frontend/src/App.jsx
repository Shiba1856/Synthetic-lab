import React, { useEffect, useMemo, useState } from 'react'
import { Activity, AlertTriangle, ArrowDownRight, ArrowUpRight, Boxes, CheckCircle2, CircleHelp, Database, GitBranch, RefreshCw, ShieldAlert, Users, Monitor, Server, RotateCcw } from 'lucide-react'

const API = 'http://127.0.0.1:8000/api'
const fmt = n => Number(n ?? 0).toLocaleString()
const severityClass = s => (s || 'Info').toLowerCase()

function Metric({ icon: Icon, label, value, sub }) {
  return <div className="metric card"><div className="metric-top"><span>{label}</span><span className="metric-icon"><Icon size={18}/></span></div><div className="metric-value">{fmt(value)}</div><div className="metric-sub">{sub}</div></div>
}
function SeverityDonut({ findings = [] }) {
  const levels = [
    { name: 'Critical', color: '#fb7185' },
    { name: 'High', color: '#f97316' },
    { name: 'Medium', color: '#fbbf24' },
    { name: 'Low', color: '#60a5fa' },
    { name: 'Info', color: '#94a3b8' },
  ].map(x => ({ ...x, count: findings.filter(f => (f.severity || '').toLowerCase() === x.name.toLowerCase()).length }))
  const total = levels.reduce((n, x) => n + x.count, 0)
  const r = 48, circumference = 2 * Math.PI * r
  let offset = 0
  return <div className="severity-chart-layout">
    <div className="donut-wrap"><svg viewBox="0 0 120 120" role="img" aria-label="Finding severity distribution">
      <circle cx="60" cy="60" r={r} fill="none" stroke="#243449" strokeWidth="14" />
      {total > 0 && levels.filter(x => x.count > 0).map(x => {
        const length = circumference * x.count / total
        const el = <circle key={x.name} cx="60" cy="60" r={r} fill="none" stroke={x.color} strokeWidth="14" strokeDasharray={`${Math.max(0,length-2)} ${circumference-length+2}`} strokeDashoffset={-offset} transform="rotate(-90 60 60)" />
        offset += length
        return el
      })}
      <text x="60" y="56" textAnchor="middle" className="donut-total">{total}</text><text x="60" y="71" textAnchor="middle" className="donut-caption">findings</text>
    </svg></div>
    <div className="severity-legend">{levels.map(x => <div key={x.name}><span className="severity-key" style={{background:x.color}}/><span>{x.name}</span><strong>{x.count}</strong><small>{total ? Math.round(x.count / total * 100) : 0}%</small></div>)}</div>
  </div>
}

function Panel({ title, subtitle, children, action }) {
  return <section className="panel card"><div className="panel-head"><div><h2>{title}</h2>{subtitle && <p>{subtitle}</p>}</div>{action}</div>{children}</section>
}
function Graph({ data }) {
  const allNodes = data?.nodes || []
  const allEdges = data?.edges || []
  const [query, setQuery] = useState('')
  const [typeFilter, setTypeFilter] = useState('all')
  const [focusId, setFocusId] = useState('')
  const [showAll, setShowAll] = useState(false)
  const nodeById = useMemo(() => new Map(allNodes.map(n => [n.id, n])), [allNodes])
  const filtered = useMemo(() => allNodes.filter(n => {
    const matchesQuery = !query || `${n.name} ${n.type} ${n.id}`.toLowerCase().includes(query.toLowerCase())
    const matchesType = typeFilter === 'all' || (n.type || '').toLowerCase() === typeFilter
    return matchesQuery && matchesType
  }), [allNodes, query, typeFilter])
  const focusNode = focusId ? nodeById.get(focusId) : null
  const focusNeighbors = useMemo(() => {
    if (!focusNode) return null
    const ids = new Set([focusNode.id])
    allEdges.forEach(e => { if (e.source === focusNode.id) ids.add(e.target); if (e.target === focusNode.id) ids.add(e.source) })
    return ids
  }, [focusNode, allEdges])
  const nodes = useMemo(() => {
    let pool = focusNeighbors ? allNodes.filter(n => focusNeighbors.has(n.id)) : filtered
    if (!showAll && !focusNeighbors && pool.length > 90) {
      // Balanced, relationship-aware overview: never let the large user population hide groups/computers.
      const byType = {user: [], group: [], computer: [], ou: [], other: []}
      pool.forEach(n => (byType[(n.type || '').toLowerCase()] || byType.other).push(n))
      const chosen = new Set()
      ;[['group', 24], ['computer', 20], ['ou', 10], ['user', 30], ['other', 6]].forEach(([t, count]) => {
        byType[t].slice(0, count).forEach(n => chosen.add(n.id))
      })
      // Add the other end of edges from selected groups/computers, but keep the canvas bounded.
      for (const e of allEdges) {
        if (chosen.size >= 100) break
        if (chosen.has(e.source) || chosen.has(e.target)) { chosen.add(e.source); chosen.add(e.target) }
      }
      pool = allNodes.filter(n => chosen.has(n.id)).slice(0, 100)
    }
    return pool
  }, [allNodes, filtered, focusNeighbors, showAll, allEdges])
  const visibleIds = useMemo(() => new Set(nodes.map(n => n.id)), [nodes])
  const edges = useMemo(() => allEdges.filter(e => visibleIds.has(e.source) && visibleIds.has(e.target)), [allEdges, visibleIds])
  const layout = useMemo(() => {
    const width = 1200
    const groups = {user: [], group: [], computer: [], ou: [], other: []}
    nodes.forEach(n => (groups[(n.type || '').toLowerCase()] || groups.other).push(n))
    const cols = [
      { key: 'user', x: 170, label: 'USERS', color: '#4e8bd9' },
      { key: 'group', x: 465, label: 'GROUPS', color: '#2f9b7e' },
      { key: 'computer', x: 760, label: 'COMPUTERS', color: '#9c7ac8' },
      { key: 'ou', x: 1050, label: 'ORGANIZATIONAL UNITS', color: '#d6a24e' },
      { key: 'other', x: 1050, label: 'OTHER', color: '#94a3b8' },
    ]
    const maxRows = Math.max(1, ...Object.values(groups).map(a => a.length))
    const height = Math.max(340, 105 + maxRows * 68)
    const positions = {}
    cols.forEach(c => groups[c.key].forEach((n, i) => { positions[n.id] = { x: c.x, y: 70 + i * 68, column: c.key } }))
    return { width, height, positions, cols, groups }
  }, [nodes])
  if (!allNodes.length) return <div className="empty">No graph data returned.</div>
  const focusOn = id => { setFocusId(id); setQuery(''); setTypeFilter('all'); setShowAll(false) }
  return <div className="graph-explorer">
    <div className="graph-controls">
      <input aria-label="Search directory objects" value={query} onChange={e => { setQuery(e.target.value); setFocusId('') }} placeholder="Search users, groups, computers…" />
      <select aria-label="Filter object type" value={typeFilter} onChange={e => { setTypeFilter(e.target.value); setFocusId('') }}>
        <option value="all">All object types</option><option value="user">Users</option><option value="group">Groups</option><option value="computer">Computers</option><option value="ou">Organizational units</option>
      </select>
      <button className="small-button" onClick={() => { setFocusId(''); setQuery(''); setTypeFilter('all'); setShowAll(false) }}>Reset view</button>
      <button className="small-button" onClick={() => setShowAll(v => !v)}>{showAll ? 'Balanced overview' : 'Show all matches'}</button>
    </div>
    {focusNode && <div className="graph-focus"><strong>Focused on:</strong> {focusNode.name} <span>· showing directly connected objects</span><button onClick={() => setFocusId('')}>Clear focus</button></div>}
    <div className="graph-scroll"><svg viewBox={`0 0 ${layout.width} ${layout.height}`} style={{height: `${layout.height}px`, minHeight:'340px'}} role="img" aria-label="Interactive synthetic directory relationship graph">
      <defs><marker id="graph-arrow" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto"><path d="M0,0 L0,6 L6,3 z" fill="#71849a"/></marker></defs>
      {layout.cols.filter(c => layout.groups[c.key].length).map(c => <g key={c.key}><text x={c.x} y="22" textAnchor="middle" className="graph-column-label">{c.label} · {layout.groups[c.key].length}</text><line x1={c.x-125} y1="35" x2={c.x+125} y2="35" stroke={c.color} strokeOpacity=".5"/></g>)}
      {edges.map((e, i) => {
        const a = layout.positions[e.source], b = layout.positions[e.target]
        if (!a || !b) return null
        const sameColumn = a.column === b.column
        const midX = (a.x + b.x) / 2
        const d = sameColumn ? `M ${a.x+100} ${a.y} C ${a.x+155} ${a.y}, ${b.x+155} ${b.y}, ${b.x+100} ${b.y}` : `M ${a.x+100} ${a.y} C ${midX} ${a.y}, ${midX} ${b.y}, ${b.x-100} ${b.y}`
        return <g key={`${e.source}-${e.target}-${i}`}><path d={d} fill="none" stroke={e.relationship?.toLowerCase().includes('admin') || e.risk_tier === 'high' ? '#fb7185' : '#71849a'} strokeOpacity=".52" strokeWidth="1.25" markerEnd="url(#graph-arrow)"/><title>{e.label || e.relationship || 'Relationship'}</title></g>
      })}
      {nodes.map(n => {
        const p = layout.positions[n.id]
        if (!p) return null
        const type = (n.type || '').toLowerCase()
        const fill = type === 'user' ? '#172d4d' : type === 'group' ? '#163c36' : type === 'computer' ? '#3a2e4c' : '#3b3424'
        const stroke = n.risk_tier === 'high' ? '#fb7185' : type === 'user' ? '#4e8bd9' : type === 'group' ? '#2f9b7e' : type === 'computer' ? '#9c7ac8' : '#d6a24e'
        const label = (n.name || n.id || 'Object').length > 25 ? `${(n.name || n.id).slice(0,22)}…` : (n.name || n.id)
        return <g key={n.id} className="graph-node" tabIndex="0" role="button" aria-label={`Focus on ${n.name}`} onClick={() => focusOn(n.id)} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') focusOn(n.id) }} transform={`translate(${p.x},${p.y})`}>
          <rect x="-100" y="-19" width="200" height="38" rx="8" fill={fill} stroke={stroke} strokeWidth={focusNode?.id === n.id ? 2.5 : 1.2}/>
          <text textAnchor="middle" y="4" fill="#f3f6fb" fontSize="11">{label}</text><title>{`${n.name} · ${n.type}${n.risk_tier ? ` · ${n.risk_tier} risk` : ''} — click to focus`}</title>
        </g>
      })}
    </svg></div>
    <div className="legend"><span>{focusNode ? `${nodes.length} connected objects` : `Showing ${nodes.length} of ${allNodes.length} objects`} · {edges.length} visible relationships</span><span><i className="dot user"/> Users</span><span><i className="dot group"/> Groups</span><span><i className="dot computer"/> Computers</span><span><i className="dot risk"/> High-risk relationships</span></div>
    {query && <div className="graph-results"><strong>{filtered.length} matching objects</strong>{filtered.slice(0, 12).map(n => <button key={n.id} onClick={() => focusOn(n.id)}>{n.name} <span>{n.type}</span></button>)}{filtered.length > 12 && <small>Showing first 12 matches. Refine your search.</small>}</div>}
  </div>
}
export default function App() {
  const [data, setData] = useState({summary:null, findings:[], graph:{nodes:[],edges:[]}, paths:[], scenarios:[], evaluation:null})
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [active, setActive] = useState('Overview')
  const [busy, setBusy] = useState(false)
  const [toast, setToast] = useState('')
  const [selectedPath, setSelectedPath] = useState(null)
  const [inventory, setInventory] = useState(null)
  const [inventorySearch, setInventorySearch] = useState('')
  async function load() {
    setLoading(true); setError('')
    try {
      const [health, summary, findings, graph, paths, scenarios, evaluation] = await Promise.all(
        ['health','summary','findings','graph','attack-paths','scenarios','evaluation'].map(async p => {
          const r = await fetch(`${API}/${p}`)
          if (!r.ok) throw new Error(`${p}: HTTP ${r.status}`)
          return r.json()
        })
      )
      if (health.mode !== 'simulation') throw new Error('Unexpected mode')
      setData({summary, findings:findings.items || [], graph, paths:paths.items || [], scenarios:scenarios.items || [], evaluation})
    } catch(e) {
      setError(`Cannot reach the FastAPI backend at ${API}. Start the backend using the README instructions. (${e.message})`)
    } finally { setLoading(false) }
  }
  useEffect(() => { load() }, [])
  async function post(url) {
    setBusy(true); setToast('')
    try {
      const r = await fetch(`${API}${url}`, {method:'POST'})
      const body = await r.json()
      if (!r.ok) throw new Error(body.detail || `HTTP ${r.status}`)
      setToast(body.message || 'Updated simulation.')
      await load()
    } catch(e) { setToast(`Action failed: ${e.message}`) }
    finally { setBusy(false) }
  }
  const s = data.summary || {}
  const nav = [
    {name:'Overview', icon:Activity},
    {name:'Findings', icon:ShieldAlert},
    {name:'Relationship Graph', icon:GitBranch},
    {name:'Potential Paths', icon:ArrowUpRight},
    {name:'Scenarios', icon:Boxes},
    {name:'Directory Inventory', icon:Database},
  ]
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><ShieldAlert size={22}/></div><div><strong>AD Insight</strong><small>Attack Simulation</small></div></div>
      <div className="side-label">WORKSPACE</div>
      <nav>{nav.map(n => <button key={n.name} className={`nav-item ${active===n.name?'selected':''}`} onClick={() => setActive(n.name)}><n.icon size={17}/><span>{n.name}</span>{n.name==='Findings' && <b>{s.findings ?? '—'}</b>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="mode-pill"><span className="live-dot"/> SIMULATION MODE</div><p>Local synthetic data<br/>No domain connection</p><button className="text-button" onClick={() => post('/reset')} disabled={busy}><RotateCcw size={14}/> Reset baseline</button></div>
    </aside>
    <main className="main">
      <header className="topbar"><div><div className="eyebrow">SECURITY ANALYTICS / LAB</div><h1>{active}</h1></div><div className="top-actions"><span className="synthetic-label"><Database size={14}/> AD-like synthetic lab data</span><button className="icon-button" title="Refresh data" onClick={load}><RefreshCw size={16}/></button></div></header>
      {error && <div className="error-banner"><AlertTriangle size={18}/><div><strong>Backend unavailable</strong><p>{error}</p></div><button onClick={load}>Retry</button></div>}
      {toast && <div className="toast">{toast}</div>}
      {loading ? <div className="loading"><span className="spinner"/> Loading simulation data…</div> : !error && <>
        {active==='Overview' && <>
          <div className="notice"><CircleHelp size={17}/><div><strong>Simulation-only environment</strong><p>These records and findings are generated examples. Potential paths are not verified vulnerabilities in a real domain.</p></div></div>
          <div className="metrics-grid">
            <Metric icon={Users} label="Directory users" value={s.users} sub={`${fmt(s.enabled_users)} enabled accounts`}/>
            <Metric icon={Boxes} label="Groups" value={s.groups} sub="Synthetic security groups"/>
            <Metric icon={Monitor} label="Computers" value={s.computers} sub="Synthetic computer objects"/>
            <Metric icon={ShieldAlert} label="Findings" value={s.findings} sub={`${s.high || 0} high severity`}/>
          </div>
          <div className="two-col">
            <Panel title="Risk overview" subtitle="Finding severity distribution · synthetic lab rules">
              <div className="risk-row"><div className="risk-number">{s.risk_score}<small>/100</small></div><div className="risk-copy"><strong>{data.evaluation?.band || 'Unrated'} simulated risk</strong><p>{data.evaluation?.method}</p></div></div>
              <div className="risk-bar"><span style={{width:`${Math.min(100,s.risk_score || 0)}%`}}/></div>
              <SeverityDonut findings={data.findings}/>
            </Panel>
            <Panel title="Dataset inventory" subtitle="Relationships loaded from local JSON">
              <div className="inventory-list"><div><span><Users size={16}/> Membership edges</span><strong>{fmt(s.memberships)}</strong></div><div><span><GitBranch size={16}/> Permission relationships</span><strong>{fmt(s.permission_edges)}</strong></div><div><span><ArrowUpRight size={16}/> Potential paths</span><strong>{fmt(data.paths.length)}</strong></div><div><span><Database size={16}/> Data source</span><strong className="source-text">Synthetic JSON</strong></div></div>
            </Panel>
          </div>
          <Panel title="Directory relationship graph" subtitle="Simplified overview of users, groups and computers" action={<button className="small-button" onClick={()=>setActive('Relationship Graph')}>Explore graph <ArrowUpRight size={14}/></button>}><Graph data={data.graph}/></Panel>
          <Panel title="Priority findings" subtitle="Highest-severity simulated findings"><FindingsTable items={data.findings.slice(0,4)}/></Panel>
        </>}
        {active==='Findings' && <Panel title="Security findings" subtitle="Rules are illustrative and operate only on synthetic data"><FindingsTable items={data.findings}/></Panel>}
        {active==='Relationship Graph' && <Panel title="Relationship graph" subtitle={`${data.graph.nodes.length} nodes · ${data.graph.edges.length} edges`}><Graph data={data.graph}/></Panel>}
        {active==='Potential Paths' && <Panel title="Potential paths" subtitle={`${data.paths.length} ranked candidate paths · synthetic data only`}><div className="notice"><CircleHelp size={17}/><div><strong>How to use these results</strong><p>Select View details to inspect each relationship and its evidence. A graph path is not proof of exploitability.</p></div></div><div className="path-list">{data.paths.length===0 ? <div className="empty">No candidate paths found. Enable a scenario or check the API.</div> : data.paths.map(p=><div className="path-item" key={p.id}><div className="path-icon"><GitBranch size={17}/></div><div className="path-content"><div className="path-title">{p.source_name} <ArrowDownRight size={14}/> {p.target_name}</div><div className="path-nodes">{p.nodes.map((n,i)=><React.Fragment key={n.id}><span>{n.name}</span>{i<p.nodes.length-1 && <b>→</b>}</React.Fragment>)}</div><p>{p.note}</p><button className="small-button" onClick={async()=>{setToast('');setSelectedPath({...p,edge_evidence:(p.edges||[]).map(e=>({...e,source_name:p.nodes.find(n=>n.id===e.source)?.name||e.source,target_name:p.nodes.find(n=>n.id===e.target)?.name||e.target,evidence:{note:'Relationship is present in the synthetic graph dataset.'}})),risk_explanation:`This candidate path connects ${p.source_name} to ${p.target_name} through ${p.length} modeled relationship(s). This is a simulation result, not proof of exploitability.`});try{const r=await fetch(`${API}/attack-paths/${encodeURIComponent(p.id)}`);if(r.ok)setSelectedPath(await r.json())}catch(e){setToast(`Showing local path details; API enrichment unavailable: ${e.message}`)}}}>View details <ArrowUpRight size={14}/></button></div><span className="path-length">{p.length} hops</span></div>)}</div>{selectedPath && <div className="path-detail-overlay" role="presentation" onClick={()=>setSelectedPath(null)}><div className="path-detail card" role="dialog" aria-modal="true" aria-label="Path investigation details" onClick={e=>e.stopPropagation()}><div className="panel-head"><div><h2>Path investigation</h2><p>{selectedPath.source_name} → {selectedPath.target_name}</p></div><button className="small-button" onClick={()=>setSelectedPath(null)}>Close</button></div><div className="notice"><ShieldAlert size={17}/><div><strong>{selectedPath.severity} candidate · {selectedPath.length} hops</strong><p>{selectedPath.risk_explanation}</p></div></div><h3>Relationship-by-relationship evidence</h3><div className="table-wrap"><table><thead><tr><th>From</th><th>Relationship</th><th>To</th><th>Evidence source</th></tr></thead><tbody>{(selectedPath.edge_evidence||[]).map((e,i)=><tr key={i}><td>{e.source_name}</td><td>{e.label}</td><td>{e.target_name}</td><td>{e.evidence.note || e.evidence.source || e.evidence.id || 'Synthetic graph relationship'}</td></tr>)}</tbody></table></div><h3>Validation checklist</h3><ul>{(selectedPath.validation||[]).map(x=><li key={x}>{x}</li>)}</ul><p><strong>Recommended next step:</strong> {selectedPath.recommendation}</p>{(selectedPath.edge_evidence||[]).map((e,i)=><button key={i} className="small-button" disabled={busy} onClick={async()=>{setBusy(true);try{const r=await fetch(`${API}/remediation/simulate`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({source_id:e.source,target_id:e.target,relationship:e.relationship})});const b=await r.json();if(!r.ok)throw new Error(b.detail||`HTTP ${r.status}`);setToast(`${b.message} Paths before: ${b.paths_before}; after: ${b.paths_after}.`);setSelectedPath(null);await load()}catch(err){setToast(`Remediation simulation failed: ${err.message}`)}finally{setBusy(false)}}}>Simulate removing “{e.label}”</button>)}</div></div>}</Panel>}
        {active==='Directory Inventory' && <Panel title="Directory inventory" subtitle="Search the expanded synthetic directory objects. No real domain is connected." action={<button className="small-button" onClick={async()=>{try{const r=await fetch(`${API}/inventory`);if(!r.ok)throw new Error(`HTTP ${r.status}`);setInventory(await r.json())}catch(e){setToast(`Inventory load failed: ${e.message}`)}}}>Load inventory</button>}><div className="inventory-list"><div><span>Users / service / privileged accounts</span><strong>{s.users} / {s.service_accounts} / {s.privileged_accounts}</strong></div><div><span>Groups / computers / OUs</span><strong>{s.groups} / {s.computers} / {s.organizational_units}</strong></div><div><span>Memberships / permissions</span><strong>{s.memberships} / {s.permission_edges}</strong></div></div><input className="inventory-search" placeholder="Search name, username, department, or ID…" value={inventorySearch} onChange={e=>setInventorySearch(e.target.value)}/>{inventory && <div className="table-wrap"><table><thead><tr><th>Object</th><th>Type</th><th>Department / details</th><th>Status / tier</th></tr></thead><tbody>{[...(inventory.users||[]).map(x=>({...x,_type:x.role==='service'?'Service account':x.role==='admin'?'Privileged account':'User',_details:x.department||x.description,_status:x.enabled?'Enabled':'Disabled'})),...(inventory.groups||[]).map(x=>({...x,_type:'Group',_details:x.description,_status:x.risk_tier})),...(inventory.computers||[]).map(x=>({...x,_type:'Computer',_details:x.os+' · '+x.type,_status:x.criticality}))].filter(x=>`${x.id} ${x.name} ${x.username||''} ${x.department||''} ${x._type}`.toLowerCase().includes(inventorySearch.toLowerCase())).slice(0,300).map(x=><tr key={x.id}><td><strong>{x.name}</strong><small>{x.id}{x.username?` · ${x.username}`:''}</small></td><td>{x._type}</td><td>{x._details}</td><td>{x._status}</td></tr>)}</tbody></table></div>}{!inventory && <div className="empty">Select “Load inventory” to fetch searchable directory records.</div>}</Panel>}
        {active==='Scenarios' && <Panel title="Simulation scenarios" subtitle="Toggle controlled changes to synthetic relationships" action={<button className="small-button" onClick={()=>post('/reset')} disabled={busy}><RotateCcw size={14}/> Reset</button>}><div className="scenario-list">{data.scenarios.map(sc=><div className="scenario" key={sc.id}><div className="scenario-info"><div className="scenario-title">{sc.name}<span className={`state ${sc.enabled?'enabled':''}`}>{sc.enabled?'Enabled':'Disabled'}</span></div><p>{sc.description}</p></div><button className={`toggle ${sc.enabled?'on':''}`} disabled={busy} onClick={()=>post(`/scenarios/${sc.id}/toggle`)}>{sc.enabled?'Disable':'Enable'}</button></div>)}</div><div className="scenario-footnote">Changes are temporary and reset when you click Reset baseline or restart the backend.</div></Panel>}
        <footer>AD Insight · Simulation Edition <span>Local-only demo · AD-like synthetic data</span></footer>
      </>}
    </main>
  </div>
}
function FindingsTable({items}) {
  if (!items?.length) return <div className="empty">No findings in this dataset.</div>
  return <div className="table-wrap"><table><thead><tr><th>Finding</th><th>Severity</th><th>Category</th><th>Asset</th><th>Recommendation</th></tr></thead><tbody>{items.map(f=><tr key={f.id}><td><strong>{f.title}</strong><small>{f.evidence}</small></td><td><span className={`severity ${severityClass(f.severity)}`}>{f.severity}</span></td><td>{f.category}</td><td>{f.asset}</td><td>{f.recommendation}</td></tr>)}</tbody></table></div>
}
