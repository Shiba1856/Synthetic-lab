from __future__ import annotations
import copy, json
from pathlib import Path
from threading import RLock

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
_lock = RLock()
_baseline = None
_state = None

def _load_json(name: str):
    with (DATA_DIR / name).open("r", encoding="utf-8") as f:
        return json.load(f)

def baseline():
    global _baseline
    if _baseline is None:
        _baseline = {
            "users": _load_json("users.json"),
            "groups": _load_json("groups.json"),
            "computers": _load_json("computers.json"),
            "ous": _load_json("ous.json"),
            "memberships": _load_json("memberships.json"),
            "permissions": _load_json("permissions.json"),
            "scenarios": _load_json("scenarios.json"),
        }
    return copy.deepcopy(_baseline)

def get_state():
    global _state
    with _lock:
        if _state is None:
            _state = baseline()
        return copy.deepcopy(_state)

def mutate(fn):
    global _state
    with _lock:
        if _state is None:
            _state = baseline()
        fn(_state)
        return copy.deepcopy(_state)

def reset():
    global _state
    with _lock:
        _state = baseline()
        return copy.deepcopy(_state)
