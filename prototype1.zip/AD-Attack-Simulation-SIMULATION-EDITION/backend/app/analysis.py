from __future__ import annotations
from collections import defaultdict, deque
import pandas as pd
import networkx as nx

SEVERITY_WEIGHT = {"Critical": 10, "High": 7, "Medium": 4, "Low": 1, "Info": 0}

def _node_map(data):
    nodes = {}
    for kind in ("users", "groups", "computers"):
        for item in data[kind]:
            nodes[item["id"]] = {**item, "type": kind[:-1] if kind != "computers" else "computer"}
    return nodes

def make_graph(data):
    nodes = _node_map(data)
    graph = nx.DiGraph()
    for node_id, item in nodes.items():
        graph.add_node(node_id, **item)
    for edge in data["memberships"]:
        if edge["member_id"] in nodes and edge["group_id"] in nodes:
            graph.add_edge(edge["member_id"], edge["group_id"], relationship="member_of", label="member of")
    for edge in data["permissions"]:
        if edge["source_id"] in nodes and edge["target_id"] in nodes:
            graph.add_edge(edge["source_id"], edge["target_id"], relationship=edge["relationship"], label=edge.get("label", edge["relationship"]), risk=edge.get("risk", "normal"), severity=edge.get("severity", "Medium"), evidence_id=edge.get("id"))
    return graph, nodes

def get_findings(data):
    findings = []
    groups = {g["id"]: g for g in data["groups"]}
    users = {u["id"]: u for u in data["users"]}
    computers = {c["id"]: c for c in data["computers"]}

    # Direct membership in a synthetic high-privilege group.
    for edge in data["memberships"]:
        group = groups.get(edge["group_id"], {})
        member_id = edge["member_id"]
        member = users.get(member_id) or groups.get(member_id) or computers.get(member_id)
        if group.get("risk_tier") == "high" and member:
            findings.append({
                "id": f"PRIV-{member_id}-{group['id']}",
                "title": f"Membership in high-privilege group: {group['name']}",
                "severity": "Critical" if group.get("name", "").lower() in ("domainadmins", "enterprise admins", "schema admins") else "High",
                "category": "Privilege exposure",
                "asset": member.get("name", member_id),
                "evidence": f"{member.get('name', member_id)} is a member of {group['name']} in the synthetic dataset.",
                "recommendation": "Review whether this membership is required; use least privilege and periodic access reviews.",
                "source": "synthetic membership rule"
            })

    # Disabled accounts still in a privileged group.
    for edge in data["memberships"]:
        group = groups.get(edge["group_id"], {})
        user = users.get(edge["member_id"])
        if user and not user.get("enabled", True) and group.get("risk_tier") == "high":
            findings.append({
                "id": f"DISABLED-PRIV-{user['id']}",
                "title": "Disabled account remains in privileged group",
                "severity": "Medium",
                "category": "Identity hygiene",
                "asset": user["name"],
                "evidence": f"{user['name']} is disabled but is still linked to {group['name']}.",
                "recommendation": "Remove obsolete group memberships when disabling or offboarding accounts.",
                "source": "synthetic membership rule"
            })

    # Permission edge to sensitive group / resource.
    for edge in data["permissions"]:
        if edge.get("risk") == "high":
            source = users.get(edge["source_id"]) or groups.get(edge["source_id"]) or computers.get(edge["source_id"])
            target = users.get(edge["target_id"]) or groups.get(edge["target_id"]) or computers.get(edge["target_id"])
            findings.append({
                "id": f"PERM-{edge['id']}",
                "title": edge.get("finding_title", "Sensitive relationship requires review"),
                "severity": edge.get("severity", "Medium"),
                "category": "Permission review",
                "asset": target.get("name", edge["target_id"]) if target else edge["target_id"],
                "evidence": f"{source.get('name', edge['source_id']) if source else edge['source_id']} has the synthetic relationship '{edge.get('label', edge['relationship'])}' to {target.get('name', edge['target_id']) if target else edge['target_id']}.",
                "recommendation": edge.get("recommendation", "Review the relationship and verify that it follows least privilege."),
                "source": "synthetic permission rule"
            })

    # Synthetic identity-hygiene findings provide a realistic severity spread.
    # These are rule-based examples, not claims about a live domain.
    for user in data["users"]:
        if user.get("enabled", True) and int(user.get("last_logon_days", 0) or 0) >= 180:
            findings.append({
                "id": f"STALE-{user['id']}",
                "title": "Enabled account with prolonged inactivity",
                "severity": "Low",
                "category": "Identity hygiene",
                "asset": user.get("name", user["id"]),
                "evidence": f"Synthetic last-logon age is {user.get('last_logon_days')} days.",
                "recommendation": "Confirm the account owner and business need; disable or remove accounts that are no longer required.",
                "source": "synthetic inactivity rule"
            })
        if user.get("enabled", True) and user.get("role") == "service":
            # Service identities deserve an explicit review, but this alone is not proof of a vulnerability.
            findings.append({
                "id": f"SVC-REVIEW-{user['id']}",
                "title": "Enabled service account requires configuration review",
                "severity": "Medium",
                "category": "Service identity",
                "asset": user.get("name", user["id"]),
                "evidence": "Synthetic inventory marks this identity as a service account; credential and delegation settings are not validated.",
                "recommendation": "Verify managed credentials, least-privilege permissions, interactive logon restrictions, and delegation settings.",
                "source": "synthetic service-account review rule"
            })

    # Make sure deterministic ordering and unique findings.
    seen = set()
    result = []
    for item in findings:
        if item["id"] not in seen:
            seen.add(item["id"])
            result.append(item)
    return sorted(result, key=lambda f: (SEVERITY_WEIGHT.get(f["severity"], 0) * -1, f["title"]))

def get_attack_paths(data, limit=60):
    graph, nodes = make_graph(data)
    targets = [g["id"] for g in data["groups"] if g.get("risk_tier") == "high"]
    sources = [u["id"] for u in data["users"] if u.get("enabled", True) and u.get("role") not in ("admin", "service")]
    results = []
    # Enumerate a small number of shortest simple paths per source/target pair to keep
    # larger synthetic datasets responsive and avoid implying every graph route is exploitable.
    for source in sources:
        for target in targets:
            if source == target or not graph.has_node(source) or not graph.has_node(target):
                continue
            try:
                for path in nx.shortest_simple_paths(graph, source, target):
                    if len(path) < 2 or len(path) > 7:
                        continue
                    edges = []
                    risky = False
                    for a, b in zip(path, path[1:]):
                        attrs = graph.get_edge_data(a, b) or {}
                        edge = {"source": a, "target": b, "relationship": attrs.get("relationship", "related"), "label": attrs.get("label", "related")}
                        edges.append(edge)
                        if attrs.get("risk") == "high": risky = True
                    results.append({
                        "id": "PATH-" + "-".join(path), "source": source, "target": target,
                        "source_name": nodes[source]["name"], "target_name": nodes[target]["name"],
                        "nodes": [{"id": n, "name": nodes[n]["name"], "type": nodes[n]["type"]} for n in path],
                        "edges": edges, "length": len(path)-1,
                        "severity": "High" if risky or nodes[target].get("risk_tier") == "high" else "Medium",
                        "confidence": "Potential",
                        "note": "Candidate path through synthetic relationships only; not a verified exploit path.",
                        "validation": ["Confirm each relationship exists in the source inventory.", "Check whether the permission is effective and applicable.", "Confirm target privilege and business context."],
                        "recommendation": "Review the edge list, remove unnecessary access at its source, then recalculate the graph."
                    })
                    # One shortest path per source-target pair avoids combinatorial growth.
                    break
            except (nx.NetworkXNoPath, nx.NodeNotFound, nx.NetworkXError):
                continue
            if len(results) >= limit * 4:
                break
        if len(results) >= limit * 4:
            break
    results.sort(key=lambda x: (0 if x["severity"] == "High" else 1, x["length"], x["source_name"].lower()))
    return results[:limit]

def get_path_detail(data, path_id):
    match = next((p for p in get_attack_paths(data, limit=100) if p["id"] == path_id), None)
    if not match:
        return None
    _, nodes = make_graph(data)
    edge_evidence = []
    for edge in match["edges"]:
        membership = next((m for m in data["memberships"] if m["member_id"] == edge["source"] and m["group_id"] == edge["target"]), None)
        permission = next((p for p in data["permissions"] if p["source_id"] == edge["source"] and p["target_id"] == edge["target"]), None)
        source = nodes.get(edge["source"], {})
        target = nodes.get(edge["target"], {})
        evidence = membership or permission or {"source": "derived graph relationship"}
        edge_evidence.append({**edge, "source_name": source.get("name", edge["source"]), "target_name": target.get("name", edge["target"]), "evidence": evidence})
    match["edge_evidence"] = edge_evidence
    match["risk_explanation"] = f"This candidate connects {match['source_name']} to sensitive group {match['target_name']} in the synthetic graph using {match['length']} relationship(s). Validate every edge before treating it as a real exposure."
    return match

def get_summary(data):
    findings = get_findings(data)
    return {
        "mode": "simulation",
        "data_source": "synthetic sample dataset",
        "users": len(data["users"]),
        "enabled_users": sum(1 for u in data["users"] if u.get("enabled", True)),
        "groups": len(data["groups"]),
        "computers": len(data["computers"]),
        "organizational_units": len(data.get("ous", [])),
        "service_accounts": sum(1 for u in data["users"] if u.get("role") == "service"),
        "privileged_accounts": sum(1 for u in data["users"] if u.get("role") == "admin"),
        "memberships": len(data["memberships"]),
        "permission_edges": len(data["permissions"]),
        "findings": len(findings),
        "critical": sum(1 for f in findings if f["severity"] == "Critical"),
        "high": sum(1 for f in findings if f["severity"] == "High"),
        "medium": sum(1 for f in findings if f["severity"] == "Medium"),
        "low": sum(1 for f in findings if f["severity"] == "Low"),
        "risk_score": min(100, sum(SEVERITY_WEIGHT.get(f["severity"], 0) for f in findings) * 4),
    }

def get_graph_data(data):
    graph, nodes = make_graph(data)
    return {
        "nodes": [
            {"id": node_id, "name": attrs["name"], "type": attrs["type"], "enabled": attrs.get("enabled", True), "risk_tier": attrs.get("risk_tier", "normal")}
            for node_id, attrs in graph.nodes(data=True)
        ],
        "edges": [
            {"source": source, "target": target, "relationship": attrs.get("relationship", "related"), "label": attrs.get("label", "")}
            for source, target, attrs in graph.edges(data=True)
        ],
    }

def get_evaluation(data):
    summary = get_summary(data)
    paths = get_attack_paths(data)
    score = summary["risk_score"]
    if score >= 70:
        band = "Elevated"
    elif score >= 35:
        band = "Moderate"
    else:
        band = "Lower"
    return {
        "score": score,
        "band": band,
        "method": "Illustrative score: severity-weighted count of simulated findings, capped at 100.",
        "finding_count": summary["findings"],
        "potential_path_count": len(paths),
        "limitations": [
            "Synthetic directory data only.",
            "Potential paths are graph relationships, not verified exploitability.",
            "This is not a production security assessment."
        ]
    }
