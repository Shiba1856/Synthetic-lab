from __future__ import annotations
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from . import data_store
from .analysis import get_summary, get_findings, get_graph_data, get_attack_paths, get_evaluation, get_path_detail

app = FastAPI(
    title="AD Attack Simulation API",
    version="1.0.0",
    description="Simulation-only educational API using synthetic directory records."
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ToggleResponse(BaseModel):
    scenario_id: str
    enabled: bool
    message: str

@app.get("/")
def root():
    return {"name": "AD Attack Simulation API", "mode": "simulation", "docs": "/docs"}

@app.get("/api/health")
def health():
    data = data_store.get_state()
    return {"status": "ok", "mode": "simulation", "data_source": "synthetic sample dataset",
            "records": sum(len(data[k]) for k in ("users","groups","computers"))}

@app.get("/api/summary")
def summary():
    return get_summary(data_store.get_state())

@app.get("/api/findings")
def findings():
    return {"items": get_findings(data_store.get_state()), "mode": "simulation"}

@app.get("/api/graph")
def graph():
    return get_graph_data(data_store.get_state())

@app.get("/api/attack-paths")
def attack_paths():
    return {"items": get_attack_paths(data_store.get_state()), "mode": "simulation"}

@app.get("/api/options")
def options():
    data = data_store.get_state()
    return {
        "users": [{"id": x["id"], "name": x["name"]} for x in data["users"]],
        "groups": [{"id": x["id"], "name": x["name"]} for x in data["groups"]],
        "computers": [{"id": x["id"], "name": x["name"]} for x in data["computers"]],
        "severities": ["Critical", "High", "Medium", "Low", "Info"],
    }

@app.get("/api/evaluation")
def evaluation():
    return get_evaluation(data_store.get_state())

@app.get("/api/scenarios")
def scenarios():
    data = data_store.get_state()
    return {"items": data["scenarios"], "mode": "simulation"}

@app.post("/api/scenarios/{scenario_id}/toggle")
def toggle_scenario(scenario_id: str):
    def apply(data):
        scenario = next((s for s in data["scenarios"] if s["id"] == scenario_id), None)
        if not scenario:
            raise HTTPException(status_code=404, detail="Scenario not found")
        scenario["enabled"] = not scenario.get("enabled", False)
        _apply_scenarios(data)
    data = data_store.mutate(apply)
    scenario = next(s for s in data["scenarios"] if s["id"] == scenario_id)
    return ToggleResponse(scenario_id=scenario_id, enabled=scenario["enabled"],
                          message=f"Scenario {'enabled' if scenario['enabled'] else 'disabled'} in simulated data.")

def _apply_scenarios(data):
    # Rebuild mutable relationships from the baseline and append enabled scenario deltas.
    base = data_store.baseline()
    enabled = {s["id"] for s in data["scenarios"] if s.get("enabled")}
    data["memberships"] = base["memberships"]
    data["permissions"] = base["permissions"]
    scenario_defs = {s["id"]: s for s in base["scenarios"]}
    for sid in enabled:
        scenario = scenario_defs.get(sid, {})
        data["memberships"].extend(scenario.get("add_memberships", []))
        data["permissions"].extend(scenario.get("add_permissions", []))
    # Deduplicate edges so repeated toggles remain deterministic.
    def unique(items, keys):
        seen, out = set(), []
        for item in items:
            key = tuple(item.get(k) for k in keys)
            if key not in seen:
                seen.add(key)
                out.append(item)
        return out
    data["memberships"] = unique(data["memberships"], ["member_id", "group_id"])
    data["permissions"] = unique(data["permissions"], ["id"])

@app.post("/api/reset")
def reset():
    data_store.reset()
    return {"status": "ok", "message": "Simulation reset to baseline sample data."}


@app.get("/api/attack-paths/{path_id}")
def attack_path_detail(path_id: str):
    detail = get_path_detail(data_store.get_state(), path_id)
    if not detail:
        raise HTTPException(status_code=404, detail="Path not found in current simulation state")
    return detail

class RemediationRequest(BaseModel):
    source_id: str
    target_id: str
    relationship: str

@app.post("/api/remediation/simulate")
def simulate_remediation(request: RemediationRequest):
    removed = {"memberships": 0, "permissions": 0}
    def apply(data):
        before = len(get_attack_paths(data, limit=100))
        old_memberships = data["memberships"]
        data["memberships"] = [m for m in old_memberships if not (m.get("member_id") == request.source_id and m.get("group_id") == request.target_id)]
        removed["memberships"] = len(old_memberships) - len(data["memberships"])
        old_permissions = data["permissions"]
        data["permissions"] = [p for p in old_permissions if not (p.get("source_id") == request.source_id and p.get("target_id") == request.target_id and p.get("relationship") == request.relationship)]
        removed["permissions"] = len(old_permissions) - len(data["permissions"])
        after = len(get_attack_paths(data, limit=100))
        removed["paths_before"] = before
        removed["paths_after"] = after
    data = data_store.mutate(apply)
    return {"status":"ok", "mode":"simulation", "message":"Simulated relationship removal applied. Reset baseline restores the original synthetic data.", **removed}

@app.get("/api/inventory")
def inventory():
    data = data_store.get_state()
    return {"users":data["users"], "groups":data["groups"], "computers":data["computers"], "organizational_units":data.get("ous", []), "memberships":len(data["memberships"]), "permissions":len(data["permissions"]), "mode":"simulation"}
