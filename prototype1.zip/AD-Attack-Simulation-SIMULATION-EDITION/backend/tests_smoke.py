from app.data_store import get_state, reset
from app.analysis import get_summary, get_findings, get_graph_data, get_attack_paths, get_path_detail

def test_simulation_data_and_analysis():
    data = get_state()
    summary = get_summary(data)
    findings = get_findings(data)
    graph = get_graph_data(data)
    paths = get_attack_paths(data)
    assert summary["mode"] == "simulation"
    assert summary["users"] >= 500
    assert summary["groups"] >= 100
    assert summary["computers"] >= 100
    assert summary["organizational_units"] >= 10
    assert summary["service_accounts"] >= 20
    assert len(findings) > 0
    assert len(graph["nodes"]) == summary["users"] + summary["groups"] + summary["computers"]
    assert all(p["confidence"] == "Potential" for p in paths)
    if paths:
        detail = get_path_detail(data, paths[0]["id"])
        assert detail and detail["edge_evidence"] and detail["validation"]

if __name__ == "__main__":
    test_simulation_data_and_analysis()
    print("Enhanced simulation smoke test passed.")
